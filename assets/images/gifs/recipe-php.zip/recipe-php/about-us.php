<?php include './inc/header.php' ?>

<div id="about-us__container">
    <h2 class="display-1 text-light">About Us</h2>

    <a href="api/v1/index.php?request=products" id="rest-api">JSON Rest API</a>
</div>


<?php include './inc/footer.php' ?>
