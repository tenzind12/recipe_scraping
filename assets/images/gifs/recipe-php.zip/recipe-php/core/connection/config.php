<?php 
   define('HOST', 'localhost');
   define('USERNAME', 'root');
   define('PASSWORD', '');
   define('DB_NAME', 'recipe');